<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="PRODUTOS POPULARES, RECOMENDAÇÕES, Todas as categorias">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>Hello Stock</title>
    <link rel="stylesheet" href="pageinicial.css" media="screen">
<link rel="stylesheet" href="Hello-Stock.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="pageinicial.js" defer=""></script>
    <meta name="generator" content="Nicepage 4.6.5, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto+Slab:100,200,300,400,500,600,700,800,900|Merriweather:300,300i,400,400i,700,700i,900,900i|Playfair+Display:400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Bahiana:400">
    
    
    
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": ""
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="Hello Stock">
    <meta property="og:type" content="website">
  </head>
  <body data-home-page="index.html" data-home-page-title="Hello Stock" class="u-body u-xl-mode"><header class="u-align-center-xs u-clearfix u-header u-section-row-container" id="sec-2b76" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction=""><div class="u-section-rows">
        <div class="u-section-row u-section-row-1" id="sec-bb33">
          <div class="u-clearfix u-sheet u-sheet-1">
            <a href="" class="u-active-none u-border-2 u-border-palette-1-base u-bottom-left-radius-0 u-bottom-right-radius-0 u-btn u-btn-rectangle u-button-style u-hover-none u-none u-radius-0 u-top-left-radius-0 u-top-right-radius-0 u-btn-1">Ajuda</a>
          </div>
          
          
          
          
          
        </div>
        <div class="u-align-center u-border-1 u-border-grey-25 u-clearfix u-image u-section-row u-image-1" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="" id="sec-fa1a" data-image-width="299" data-image-height="186">
          <div class="u-clearfix u-sheet u-sheet-2">
            <a href="" class="u-border-1 u-border-active-white u-border-hover-white u-btn u-button-style u-none u-text-white u-btn-2"><span class="u-file-icon u-icon u-icon-1"><img src="images/6555213.png" alt=""></span>
              <br>Entrar
            </a>
            <a href="" class="u-border-1 u-border-active-palette-2-base u-border-hover-palette-1-base u-btn u-button-style u-none u-text-white u-btn-3"><span class="u-file-icon u-icon u-icon-2"><img src="images/1168665.png" alt=""></span>&nbsp;<br>Favoritos
            </a>
            <a href="" class="u-active-none u-btn u-button-style u-custom-font u-font-arial u-hover-none u-none u-text-hover-palette-2-base u-text-white u-btn-4"><span class="u-icon"></span>&nbsp; <span class="u-file-icon u-icon u-icon-4"><img src="images/5233760.png" alt=""></span>&nbsp;Carrinho
            </a>
            <p class="infinite u-custom-font u-text u-text-palette-3-light-2 u-text-1" data-animation-name="rubberBand" data-animation-duration="1750" data-animation-direction="" data-animation-delay="0">Hello Stock</p>
            <form action="#" method="get" class="u-align-center u-border-3 u-border-white u-expanded-width-xs u-palette-3-light-2 u-radius-6 u-search u-search-left u-search-1">
              <button class="u-search-button" type="submit">
                <span class="u-search-icon u-spacing-10 u-search-icon-1">
                  <svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 56.966 56.966"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-73a9"></use></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="svg-73a9" x="0px" y="0px" viewBox="0 0 56.966 56.966" style="enable-background:new 0 0 56.966 56.966;" xml:space="preserve" class="u-svg-content"><path d="M55.146,51.887L41.588,37.786c3.486-4.144,5.396-9.358,5.396-14.786c0-12.682-10.318-23-23-23s-23,10.318-23,23  s10.318,23,23,23c4.761,0,9.298-1.436,13.177-4.162l13.661,14.208c0.571,0.593,1.339,0.92,2.162,0.92  c0.779,0,1.518-0.297,2.079-0.837C56.255,54.982,56.293,53.08,55.146,51.887z M23.984,6c9.374,0,17,7.626,17,17s-7.626,17-17,17  s-17-7.626-17-17S14.61,6,23.984,6z"></path></svg>
                </span>
              </button>
              <input class="u-custom-font u-font-playfair-display u-search-input u-search-input-1" type="search" name="search" value="" placeholder="Search">
            </form>
            <a href="" class="u-border-1 u-border-active-palette-2-base u-border-hover-palette-1-base u-btn u-button-style u-none u-text-palette-1-base u-btn-5"></a>
          </div>
          
          
          
          
          
          <style class="u-sticky-style" data-style-id="91f6">.u-sticky-fixed.u-sticky-91f6:before, .u-body.u-sticky-fixed .u-sticky-91f6:before {
border: top right bottom left !important; border-color: #404040 !important; border-width: 2px !important
}</style>
        </div>
        <div class="u-palette-5-dark-2 u-section-row u-section-row-3" id="sec-fd2d">
          <div class="u-clearfix u-sheet u-valign-middle u-sheet-3">
            <nav class="u-menu u-menu-dropdown u-offcanvas u-menu-1" data-submenu-level="on-click" data-position="menuCate">
              <div class="menu-collapse u-custom-font u-font-playfair-display" style="font-size: 1.25rem; letter-spacing: 0px; text-transform: uppercase; font-weight: 700;">
                <a class="u-button-style u-custom-active-border-color u-custom-active-color u-custom-border u-custom-border-color u-custom-border-radius u-custom-borders u-custom-color u-custom-hover-border-color u-custom-hover-color u-custom-left-right-menu-spacing u-custom-text-active-color u-custom-text-color u-custom-text-hover-color u-custom-text-shadow u-custom-text-shadow-blur u-custom-text-shadow-color u-custom-text-shadow-transparency u-custom-text-shadow-x u-custom-text-shadow-y u-custom-top-bottom-menu-spacing u-nav-link" href="#">
                  <svg class="u-svg-link" viewBox="0 0 24 24"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-ab53"></use></svg>
                  <svg class="u-svg-content" version="1.1" id="svg-ab53" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</g></svg>
                </a>
              </div>
              <div class="u-custom-menu u-nav-container">
                <ul class="u-custom-font u-font-playfair-display u-nav u-spacing-30 u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-border-active-white u-border-hover-white u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-black u-text-palette-2-light-2" style="padding: 10px 0px; text-shadow: 2px 2px 8px rgba(0,0,0,0.4);">Dashboards</a>
</li><li class="u-nav-item"><a class="u-border-active-white u-border-hover-white u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-black u-text-palette-2-light-2" style="padding: 10px 0px; text-shadow: 2px 2px 8px rgba(0,0,0,0.4);">Hello Stock</a>
</li><li class="u-nav-item"><a class="u-border-active-white u-border-hover-white u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-black u-text-palette-2-light-2" href="Administração.html" style="padding: 10px 0px; text-shadow: 2px 2px 8px rgba(0,0,0,0.4);">Administração</a>
</li><li class="u-nav-item"><a class="u-border-active-white u-border-hover-white u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-black u-text-palette-2-light-2" href="Compra-Fácil.html" style="padding: 10px 0px; text-shadow: 2px 2px 8px rgba(0,0,0,0.4);">Compra Fácil</a>
</li><li class="u-nav-item"><a class="u-border-active-white u-border-hover-white u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-black u-text-palette-2-light-2" href="Cadastrar-Lote.html" style="padding: 10px 0px; text-shadow: 2px 2px 8px rgba(0,0,0,0.4);">Cadastrar Lote</a>
</li></ul>
              </div>
              <div class="u-custom-menu u-nav-container-collapse">
                <div class="u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav u-white">
                  <div class="u-inner-container-layout u-sidenav-overflow">
                    <div class="u-menu-close"></div>
                    <ul class="u-align-center u-custom-font u-font-arial u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" style="padding: 10px 20px;">Dashboards</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" style="padding: 10px 20px;">Hello Stock</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Administração.html" style="padding: 10px 20px;">Administração</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Compra-Fácil.html" style="padding: 10px 20px;">Compra Fácil</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Cadastrar-Lote.html" style="padding: 10px 20px;">Cadastrar Lote</a>
</li></ul>
                  </div>
                </div>
                <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
              </div>
            </nav>
          </div>
          
          
          
          
          
        </div>
      </div></header>
    <section class="u-align-center u-clearfix u-custom-color-1 u-section-1" id="sec-93ef">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-align-center u-carousel u-gallery u-gallery-slider u-layout-carousel u-lightbox u-no-transition u-show-text-on-hover u-gallery-1" id="carousel-c2ea" data-interval="5000" data-u-ride="carousel">
          <ol class="u-absolute-hcenter u-carousel-indicators u-carousel-indicators-1">
            <li data-u-target="#carousel-c2ea" data-u-slide-to="0" class="u-active u-grey-70 u-shape-circle" style="width: 10px; height: 10px;"></li>
            <li data-u-target="#carousel-c2ea" data-u-slide-to="1" class="u-grey-70 u-shape-circle" style="width: 10px; height: 10px;"></li>
          </ol>
          <div class="u-carousel-inner u-gallery-inner" role="listbox">
            <div class="u-active u-carousel-item u-effect-fade u-effect-hover-slide u-gallery-item u-carousel-item-1">
              <div class="u-back-slide">
                <img class="u-back-image u-expanded u-back-image-1" src="images/5.svg" alt="Sample Headline">
              </div>
              <div class="u-align-center u-over-slide u-shading u-valign-bottom u-over-slide-1">
                <h3 class="u-gallery-heading">Sample Headline</h3>
                <p class="u-gallery-text" style="margin-top: 0px;">Sample Text</p>
              </div>
            </div>
            <div class="u-carousel-item u-effect-fade u-effect-hover-slide u-gallery-item u-carousel-item-2">
              <div class="u-back-slide">
                <img class="u-back-image u-expanded u-back-image-2" src="images/5.svg">
              </div>
              <div class="u-align-center u-over-slide u-shading u-valign-bottom u-over-slide-2">
                <h3 class="u-gallery-heading">Sample Title</h3>
                <p class="u-gallery-text" style="margin-top: 0px;">Sample Text</p>
              </div>
            </div>
          </div>
          <a class="u-absolute-vcenter u-carousel-control u-carousel-control-prev u-grey-70 u-icon-circle u-opacity u-opacity-70 u-spacing-10 u-text-white u-carousel-control-1" href="#carousel-c2ea" role="button" data-u-slide="prev">
            <span aria-hidden="true">
              <svg viewBox="0 0 451.847 451.847"><path d="M97.141,225.92c0-8.095,3.091-16.192,9.259-22.366L300.689,9.27c12.359-12.359,32.397-12.359,44.751,0
c12.354,12.354,12.354,32.388,0,44.748L173.525,225.92l171.903,171.909c12.354,12.354,12.354,32.391,0,44.744
c-12.354,12.365-32.386,12.365-44.745,0l-194.29-194.281C100.226,242.115,97.141,234.018,97.141,225.92z"></path></svg>
            </span>
            <span class="sr-only">
              <svg viewBox="0 0 451.847 451.847"><path d="M97.141,225.92c0-8.095,3.091-16.192,9.259-22.366L300.689,9.27c12.359-12.359,32.397-12.359,44.751,0
c12.354,12.354,12.354,32.388,0,44.748L173.525,225.92l171.903,171.909c12.354,12.354,12.354,32.391,0,44.744
c-12.354,12.365-32.386,12.365-44.745,0l-194.29-194.281C100.226,242.115,97.141,234.018,97.141,225.92z"></path></svg>
            </span>
          </a>
          <a class="u-absolute-vcenter u-carousel-control u-carousel-control-next u-grey-70 u-icon-circle u-opacity u-opacity-70 u-spacing-10 u-text-white u-carousel-control-2" href="#carousel-c2ea" role="button" data-u-slide="next">
            <span aria-hidden="true">
              <svg viewBox="0 0 451.846 451.847"><path d="M345.441,248.292L151.154,442.573c-12.359,12.365-32.397,12.365-44.75,0c-12.354-12.354-12.354-32.391,0-44.744
L278.318,225.92L106.409,54.017c-12.354-12.359-12.354-32.394,0-44.748c12.354-12.359,32.391-12.359,44.75,0l194.287,194.284
c6.177,6.18,9.262,14.271,9.262,22.366C354.708,234.018,351.617,242.115,345.441,248.292z"></path></svg>
            </span>
            <span class="sr-only">
              <svg viewBox="0 0 451.846 451.847"><path d="M345.441,248.292L151.154,442.573c-12.359,12.365-32.397,12.365-44.75,0c-12.354-12.354-12.354-32.391,0-44.744
L278.318,225.92L106.409,54.017c-12.354-12.359-12.354-32.394,0-44.748c12.354-12.359,32.391-12.359,44.75,0l194.287,194.284
c6.177,6.18,9.262,14.271,9.262,22.366C354.708,234.018,351.617,242.115,345.441,248.292z"></path></svg>
            </span>
          </a>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-custom-color-1 u-section-2" id="sec-c72d">
      <div class="u-clearfix u-sheet u-valign-top-xs u-sheet-1">
        <h1 class="u-align-center u-custom-font u-font-roboto-slab u-text u-text-black u-text-1">PRODUTOS POPULARES</h1>
        <div class="u-layout-grid u-list u-list-1">
          <div class="u-repeater u-repeater-1">
            <div class="u-align-center u-border-4 u-border-grey-25 u-container-style u-list-item u-repeater-item u-white u-list-item-1">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-1">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-1" data-image-width="2836" data-image-height="1875" src="images/6.svg">
                <h3 class="u-text u-text-default u-text-2">Classic T-Shirt</h3>
                <h5 class="u-text u-text-palette-2-base u-text-3">$20.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-1">add to cart</a>
              </div>
            </div>
            <div class="u-align-center u-border-4 u-border-grey-25 u-container-style u-list-item u-repeater-item u-white u-list-item-2">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-2">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-2" data-image-width="2836" data-image-height="1875" src="images/7.svg">
                <h3 class="u-text u-text-default u-text-4">Red Shoes</h3>
                <h5 class="u-text u-text-palette-2-base u-text-5">$240.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-2">add to cart</a>
              </div>
            </div>
            <div class="u-align-center u-border-4 u-border-grey-25 u-container-style u-list-item u-repeater-item u-white u-list-item-3">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-3">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-3" data-image-width="2836" data-image-height="1875" src="images/8.svg">
                <h3 class="u-text u-text-default u-text-6">Summer Hat</h3>
                <h5 class="u-text u-text-palette-2-base u-text-7">$7.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-3">add to cart</a>
              </div>
            </div>
            <div class="u-align-center u-border-4 u-border-grey-25 u-container-style u-list-item u-repeater-item u-white u-list-item-4">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-4">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-4" data-image-width="2836" data-image-height="1875" src="images/8.svg">
                <h3 class="u-text u-text-default u-text-8">Summer Hat</h3>
                <h5 class="u-text u-text-palette-2-base u-text-9">$7.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-4">add to cart</a>
              </div>
            </div>
            <div class="u-align-center u-border-4 u-border-grey-25 u-container-style u-list-item u-repeater-item u-white u-list-item-5">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-5">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-5" data-image-width="2836" data-image-height="1875" src="images/8.svg">
                <h3 class="u-text u-text-default u-text-10">Summer Hat</h3>
                <h5 class="u-text u-text-palette-2-base u-text-11">$7.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-5">add to cart</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-custom-color-1 u-section-3" id="sec-6c22">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h2 class="u-align-left u-custom-font u-font-merriweather u-text u-text-black u-text-default u-text-1">RECOMENDAÇÕES</h2>
        <div class="u-layout-horizontal u-list u-list-1">
          <div class="u-repeater u-repeater-1">
            <div class="u-align-center u-border-3 u-border-grey-75 u-container-style u-list-item u-radius-34 u-repeater-item u-shape-round u-white u-list-item-1">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-1">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-1" data-image-width="2836" data-image-height="1875" src="images/6.svg">
                <h3 class="u-text u-text-default u-text-2">Classic T-Shirt</h3>
                <h5 class="u-text u-text-palette-2-base u-text-3">$20.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-1">add to cart</a>
              </div>
            </div>
            <div class="u-align-center u-border-3 u-border-grey-75 u-container-style u-list-item u-radius-34 u-repeater-item u-shape-round u-white u-list-item-2">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-2">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-2" data-image-width="2836" data-image-height="1875" src="images/7.svg">
                <h3 class="u-text u-text-default u-text-4">Red Shoes</h3>
                <h5 class="u-text u-text-palette-2-base u-text-5">$240.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-2">add to cart</a>
              </div>
            </div>
            <div class="u-align-center u-border-3 u-border-grey-75 u-container-style u-list-item u-radius-34 u-repeater-item u-shape-round u-white u-list-item-3">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-3">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-3" data-image-width="2836" data-image-height="1875" src="images/8.svg">
                <h3 class="u-text u-text-default u-text-6">Summer Hat</h3>
                <h5 class="u-text u-text-palette-2-base u-text-7">$7.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-3">add to cart</a>
              </div>
            </div>
            <div class="u-align-center u-border-3 u-border-grey-75 u-container-style u-list-item u-radius-34 u-repeater-item u-shape-round u-white u-list-item-4">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-4">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-4" data-image-width="2836" data-image-height="1875" src="images/8.svg">
                <h3 class="u-text u-text-default u-text-8">Summer Hat</h3>
                <h5 class="u-text u-text-palette-2-base u-text-9">$7.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-4">add to cart</a>
              </div>
            </div>
            <div class="u-align-center u-border-3 u-border-grey-75 u-container-style u-list-item u-radius-34 u-repeater-item u-shape-round u-white u-list-item-5">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-5">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-5" data-image-width="2836" data-image-height="1875" src="images/8.svg">
                <h3 class="u-text u-text-default u-text-10">Summer Hat</h3>
                <h5 class="u-text u-text-palette-2-base u-text-11">$7.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-5">add to cart</a>
              </div>
            </div>
            <div class="u-align-center u-border-3 u-border-grey-75 u-container-style u-list-item u-radius-34 u-repeater-item u-shape-round u-white u-list-item-6">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-6">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-6" data-image-width="2836" data-image-height="1875" src="images/8.svg">
                <h3 class="u-text u-text-default u-text-12">Summer Hat</h3>
                <h5 class="u-text u-text-palette-2-base u-text-13">$7.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-6">add to cart</a>
              </div>
            </div>
            <div class="u-align-center u-border-3 u-border-grey-75 u-container-style u-list-item u-radius-34 u-repeater-item u-shape-round u-white u-list-item-7">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-7">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-7" data-image-width="2836" data-image-height="1875" src="images/8.svg">
                <h3 class="u-text u-text-default u-text-14">Summer Hat</h3>
                <h5 class="u-text u-text-palette-2-base u-text-15">$7.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-7">add to cart</a>
              </div>
            </div>
            <div class="u-align-center u-border-3 u-border-grey-75 u-container-style u-list-item u-radius-34 u-repeater-item u-shape-round u-white u-list-item-8">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-8">
                <img alt="" class="u-expanded-width u-image u-image-default u-image-8" data-image-width="2836" data-image-height="1875" src="images/8.svg">
                <h3 class="u-text u-text-default u-text-16">Summer Hat</h3>
                <h5 class="u-text u-text-palette-2-base u-text-17">$7.00</h5>
                <a href="" class="u-border-2 u-border-grey-25 u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-btn-8">add to cart</a>
              </div>
            </div>
          </div>
          <a class="u-border-2 u-border-palette-1-base u-gallery-nav u-gallery-nav-prev u-icon-rectangle u-opacity u-opacity-70 u-spacing-10 u-text-black u-gallery-nav-1" href="#" role="button">
            <span aria-hidden="true">
              <svg viewBox="0 0 451.847 451.847"><path d="M97.141,225.92c0-8.095,3.091-16.192,9.259-22.366L300.689,9.27c12.359-12.359,32.397-12.359,44.751,0
c12.354,12.354,12.354,32.388,0,44.748L173.525,225.92l171.903,171.909c12.354,12.354,12.354,32.391,0,44.744
c-12.354,12.365-32.386,12.365-44.745,0l-194.29-194.281C100.226,242.115,97.141,234.018,97.141,225.92z"></path></svg>
            </span>
            <span class="sr-only">
              <svg viewBox="0 0 451.847 451.847"><path d="M97.141,225.92c0-8.095,3.091-16.192,9.259-22.366L300.689,9.27c12.359-12.359,32.397-12.359,44.751,0
c12.354,12.354,12.354,32.388,0,44.748L173.525,225.92l171.903,171.909c12.354,12.354,12.354,32.391,0,44.744
c-12.354,12.365-32.386,12.365-44.745,0l-194.29-194.281C100.226,242.115,97.141,234.018,97.141,225.92z"></path></svg>
            </span>
          </a>
          <a class="u-absolute-vcenter u-border-2 u-border-palette-1-base u-gallery-nav u-gallery-nav-next u-icon-rectangle u-opacity u-opacity-70 u-spacing-10 u-text-black u-gallery-nav-2" href="#" role="button">
            <span aria-hidden="true">
              <svg viewBox="0 0 451.846 451.847"><path d="M345.441,248.292L151.154,442.573c-12.359,12.365-32.397,12.365-44.75,0c-12.354-12.354-12.354-32.391,0-44.744
L278.318,225.92L106.409,54.017c-12.354-12.359-12.354-32.394,0-44.748c12.354-12.359,32.391-12.359,44.75,0l194.287,194.284
c6.177,6.18,9.262,14.271,9.262,22.366C354.708,234.018,351.617,242.115,345.441,248.292z"></path></svg>
            </span>
            <span class="sr-only">
              <svg viewBox="0 0 451.846 451.847"><path d="M345.441,248.292L151.154,442.573c-12.359,12.365-32.397,12.365-44.75,0c-12.354-12.354-12.354-32.391,0-44.744
L278.318,225.92L106.409,54.017c-12.354-12.359-12.354-32.394,0-44.748c12.354-12.359,32.391-12.359,44.75,0l194.287,194.284
c6.177,6.18,9.262,14.271,9.262,22.366C354.708,234.018,351.617,242.115,345.441,248.292z"></path></svg>
            </span>
          </a>
        </div>
      </div>
    </section>
    <section class="u-align-center u-clearfix u-custom-color-1 u-section-4" id="sec-4d0c">
      <div class="u-align-left u-clearfix u-sheet u-sheet-1">
        <h1 class="u-custom-font u-font-merriweather u-text u-text-black u-text-default u-text-1">Todas as categorias</h1>
        <div class="u-layout-grid u-list u-list-1">
          <div class="u-repeater u-repeater-1">
            <div class="u-border-3 u-border-white u-container-style u-list-item u-radius-50 u-repeater-item u-shape-round u-list-item-1" data-href="">
              <div class="u-container-layout u-similar-container u-container-layout-1"><span class="u-file-icon u-icon u-icon-1"><img src="images/148997.png" alt=""></span>
                <h3 class="u-align-center u-text u-text-default u-text-2">Aparelhos eletrônicos</h3>
              </div>
            </div>
            <div class="u-align-center u-border-3 u-border-white u-container-style u-list-item u-radius-50 u-repeater-item u-shape-round u-list-item-2" data-href="">
              <div class="u-container-layout u-similar-container u-container-layout-2"><span class="u-file-icon u-icon u-icon-2"><img src="images/148712.png" alt=""></span>
                <h3 class="u-align-center u-text u-text-default u-text-3">Decorações</h3>
              </div>
            </div>
            <div class="u-border-3 u-border-white u-container-style u-list-item u-radius-50 u-repeater-item u-shape-round u-list-item-3" data-href="">
              <div class="u-container-layout u-similar-container u-container-layout-3"><span class="u-file-icon u-icon u-icon-3"><img src="images/4831802.png" alt=""></span>
                <h3 class="u-align-center u-text u-text-default u-text-4">Acessórios de Moda</h3>
              </div>
            </div>
            <div class="u-border-3 u-border-white u-container-style u-list-item u-radius-50 u-repeater-item u-shape-round u-list-item-4" data-href="">
              <div class="u-container-layout u-similar-container u-container-layout-4"><span class="u-file-icon u-icon u-icon-4"><img src="images/2936886.png" alt=""></span>
                <h3 class="u-align-center u-text u-text-default u-text-5">Equipamentos de Academia</h3>
              </div>
            </div>
            <div class="u-border-3 u-border-white u-container-style u-list-item u-radius-50 u-repeater-item u-shape-round u-list-item-5" data-href="">
              <div class="u-container-layout u-similar-container u-container-layout-5"><span class="u-file-icon u-icon u-icon-5"><img src="images/3531827.png" alt=""></span>
                <h3 class="u-align-center u-text u-text-default u-text-6">Roupas Masculinas</h3>
              </div>
            </div>
            <div class="u-border-3 u-border-white u-container-style u-list-item u-radius-50 u-repeater-item u-shape-round u-list-item-6" data-href="">
              <div class="u-container-layout u-similar-container u-container-layout-6"><span class="u-file-icon u-icon u-icon-6"><img src="images/1785375.png" alt=""></span>
                <h3 class="u-align-center u-text u-text-default u-text-7">Roupas Femininas</h3>
              </div>
            </div>
            <div class="u-border-3 u-border-white u-container-style u-list-item u-radius-50 u-repeater-item u-shape-round u-list-item-7" data-href="">
              <div class="u-container-layout u-similar-container u-container-layout-7"><span class="u-file-icon u-icon u-icon-7"><img src="images/1597574.png" alt=""></span>
                <h3 class="u-align-center u-text u-text-default u-text-8">Aparelhos eletrodomésticos</h3>
              </div>
            </div>
            <div class="u-border-3 u-border-white u-container-style u-list-item u-radius-50 u-repeater-item u-shape-round u-list-item-8" data-href="">
              <div class="u-container-layout u-similar-container u-container-layout-8"><span class="u-file-icon u-icon u-icon-8"><img src="images/6596262.png" alt=""></span>
                <h3 class="u-align-center u-text u-text-default u-text-9">Iluminação</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
  </body>
</html>